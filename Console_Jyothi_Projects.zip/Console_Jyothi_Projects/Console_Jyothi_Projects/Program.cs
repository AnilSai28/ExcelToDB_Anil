﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.IO;

namespace Console_Jyothi_Projects
{
    class Program
    {
      
        static void Main(string[] args)
        {
            log4net.ILog log = log4net.LogManager.GetLogger(typeof(Program));
       
            if (args ==null || args.Length==0)
            {
                Console.WriteLine("Run the Application by passing the Full File Name Ex : Console_Jyoti_Projects C:/.../Test.xlsx");
               
            }
            else
            {
                FileDAL dal = new FileDAL();
                try
                {
                    Console.WriteLine("Log File Create at : " + dal.locallogfile);
                    string FileName = args[0];
                    Console.WriteLine("File Name : " + FileName);
                   
                    int rowsconverted = dal.ExcelToDB(FileName);
                    Console.WriteLine("Excel to Database Conversion Done Successfullly : Affected Rows : " + rowsconverted);
                    dal.LogEntry("Excel to Database Conversion Done Successfullly : Affected Rows : " + rowsconverted);
                    log.Error("Excel to Database Conversion Done Successfullly : Affected Rows : " + rowsconverted);

                }
                catch (System.IO.IOException exp)
                {
                    Console.WriteLine("Invalid File : " + exp.Message);
                    dal.LogEntry("Invalid File : " + exp.Message);

                }
                catch(Exception exp)
                {
                    Console.WriteLine("Error while parsing the data : " + exp.Message + " /n" + exp.StackTrace);
                    dal.LogEntry("Error while parsing the data : " + exp.Message + " /n" + exp.StackTrace);
                }
            }

            Console.WriteLine("Press Enter Key to Exit");
            Console.ReadLine();
          
        }
    }
}
