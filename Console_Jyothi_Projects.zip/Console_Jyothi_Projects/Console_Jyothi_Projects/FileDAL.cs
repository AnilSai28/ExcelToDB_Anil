﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OleDb;
using System.IO;

namespace Console_Jyothi_Projects
{
   public class FileDAL
    {
        log4net.ILog log = log4net.LogManager.GetLogger(typeof(FileDAL));
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddInDB(List<FileModel> list)
        {
            try
            {
                int rowaffected = 0;
                con.Open();
                foreach (var model in list)
                {
                    SqlCommand com_add = new SqlCommand("Proc_AddFiles", con);
                    com_add.Parameters.AddWithValue("@sku", model.SKU);
                    com_add.Parameters.AddWithValue("@asin", model.Asin);
                    com_add.Parameters.AddWithValue("@condition", model.Condition);
                    com_add.Parameters.AddWithValue("@title", model.Title);
                    com_add.Parameters.AddWithValue("@quantity", model.Quantity);
                    com_add.Parameters.AddWithValue("@price", model.Price);

                    com_add.CommandType = CommandType.StoredProcedure;
                    SqlParameter para_ret = new SqlParameter();
                    para_ret.Direction = ParameterDirection.ReturnValue;
                    com_add.Parameters.Add(para_ret);

                    try
                    {
                        com_add.ExecuteNonQuery();

                        int count = Convert.ToInt32(para_ret.Value);
                        if (count == 1)
                        {
                            //Log Entry
                           
                            Console.WriteLine("Duplicate Row , SKU : {0}", model.SKU);
                            this.LogEntry("Duplicate Row , SKU : "+ model.SKU);
                        }
                        else
                        {
                            rowaffected++;
                            Console.WriteLine("Row Added in DB : SKU : " + model.SKU);
                            this.LogEntry("Row Added in DB : SKU : " + model.SKU);
                        }
                    }
                    catch(Exception exp)
                    {
                        Console.WriteLine("Error while adding row in DB , SKU :{0} , Exception Details : {1}" , model.SKU,exp.Message);
                        this.LogEntry("Error while adding row in DB , SKU : "+ model.SKU + " , Exception Details : "+ exp.Message);
                    }
                }
                con.Close();
                Console.WriteLine("Rows added in DB : " + rowaffected);
                this.LogEntry("Rows added in DB : " + rowaffected);
                return rowaffected;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<FileModel> ExceltoObject(string FileName)
        {
            try
            {
                if (File.Exists(FileName) && FileName.EndsWith(".xlsx"))
                {
                    List<FileModel> model = new List<FileModel>();

                    string constr =
        ConfigurationManager.ConnectionStrings["excel"].ConnectionString + FileName + ";";
                    OleDbConnection con = new OleDbConnection(constr);

                    con.Open();
                    OleDbCommand command = new OleDbCommand("select * from [Sheet1$]", con);
                    OleDbDataReader dr = command.ExecuteReader();

                    while (dr.Read())
                    {
                        FileModel m = new FileModel();
                        int price, qty;
                        if (dr.GetString(0) == string.Empty || dr.GetString(1) == string.Empty
                            || dr.GetString(2) == string.Empty   || dr.GetString(3) == string.Empty
                            || !int.TryParse(dr[4].ToString(), out price) || !int.TryParse(dr[5].ToString(), out qty ) || (dr.GetString(2) != "New" && dr.GetString(2) != "Used"))
                        {
                            //Log Entry
                            Console.WriteLine("Invalid Row in the File : ({0}) : , File Name : {0} : ", dr.GetString(0), FileName);
                            this.LogEntry("Invalid Row in the File : ("+ dr.GetString(0) + ") : , File Name : "+ FileName);
                        }
                        else
                        {
                            m.SKU = dr.GetString(0);
                            m.Asin = dr.GetString(1);
                            m.Condition = dr.GetString(2);
                            m.Title = dr.GetString(3);
                            m.Quantity = qty;
                            m.Price = price;
                            model.Add(m);
                            Console.WriteLine("Row Converted to Excel to Object , SKU : " + m.SKU);
                            this.LogEntry("Row Converted to Excel to Object , SKU : " + m.SKU);
                        }


                    }
                    con.Close();


                    return model;
                }
                else
                {
                    //log entry
                    Console.WriteLine("File Does Not Exist or Has the Wrong Extension : "+FileName);
                    this.LogEntry("File Does Not Exist or Has the Wrong Extension : " + FileName);

                    return null;
                }
            }
            finally
            {
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
            }

        public int ExcelToDB(string FileName)
        {
            List<FileModel> list = this.ExceltoObject(FileName);
            if (list != null)
            {
                int rowconverted = this.AddInDB(list);
                return rowconverted;
            }
            //Log
           
            return 0;
        }

    public readonly  string locallogfile = AppDomain.CurrentDomain.BaseDirectory+ "/" + Guid.NewGuid() + ".txt";
      
        public void LogEntry(string msg)
        {
            FileStream fs = new FileStream(locallogfile, FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(DateTime.Now.ToString()+ " : "+msg );
            sw.Flush();
            fs.Close();
        }
    }
}
