﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Console_Jyothi_Projects;

namespace NUnitTestCases
{
    [TestFixture]
    public class MyTestClass
    {
        [Test]
        public void Test1()
        {
            int i1 = 100;
            int i2 = 200;
            int total = i1 + i2;
            Assert.AreEqual(total, 300);
        }
        [Test]
        public void TestExcelToObject()
        {
            Console_Jyothi_Projects.FileDAL dalobj = new Console_Jyothi_Projects.FileDAL();
            string filename = @"C:\anil.net\Console_Jyothi_Projects\Console_Jyothi_Projects\bin\Debug\Test.xlsx";
            var list = dalobj.ExceltoObject(filename);
            int rows = 5;//File has 5 rows to convert
            Assert.AreEqual(list.Count, rows);
        }
        [Test]
        public void TestObjectToDB()
        {
            List<FileModel> list = new List<FileModel>();
            FileModel m = new FileModel();
            m.SKU = "SkU10";
            m.Asin = "Bgl";
            m.Condition = "New";
            m.Title = "sureka";
            m.Quantity = 38;
            m.Price = 39999;

            list.Add(m);
            FileModel m1 = new FileModel();
            m1.SKU = "SkU11";
            m1.Asin = "Chennai";
            m1.Condition = "New";
            m1.Title = "Anil";
            m1.Quantity = 38;
            m1.Price = 39999;
            list.Add(m1);

            Console_Jyothi_Projects.FileDAL dalobj = new Console_Jyothi_Projects.FileDAL();
            int count=  dalobj.AddInDB(list);
            Assert.AreEqual(count, list.Count);
        }


    
         [Test]
        public void TestExcelToDB()
        {
            Console_Jyothi_Projects.FileDAL dalobj = new Console_Jyothi_Projects.FileDAL();
            string filename = @"C:\anil.net\Console_Jyothi_Projects\Console_Jyothi_Projects\bin\Debug\Test.xlsx";
            var list = dalobj.ExceltoObject(filename);
            int count = dalobj.AddInDB(list);
            Assert.AreEqual(count, list.Count);
        }
    }
}
